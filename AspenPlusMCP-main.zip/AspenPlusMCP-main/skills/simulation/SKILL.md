---
name: simulation
description: Simulation execution and verification guides for Aspen Plus.
---

# Simulation Skills

Guides for running and verifying Aspen Plus simulations.

## Available Resources

| Resource | Description |
|----------|-------------|
| `RUN.md` | Simulation execution methods |

## Usage

```python
skills(category='simulation', name='RUN')
```

## Tools

- `check_model_completion_status` - Pre-run check
- `check_and_run` - Smart execution
- `run_simulation` - Direct execution
- `run_and_report` - Execution with report
