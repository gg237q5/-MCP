# Aspen Plus MCP Overview

## Model Building Workflow

```
1. Create input file (create_inp_file)
      ↓
2. Open file (open_aspen_plus)
      ↓
3. Set thermodynamic method (add_thermo_method)
      ↓
4. Save/Close/Reopen
      ↓
5. Add blocks and streams (add_block, add_stream)
      ↓
6. Connect streams (connect_block_stream)
      ↓
7. Set stream conditions (set_stream_input_conditions)
      ↓
8. Set block specs (set_block_input_specifications)
      ↓
9. Auto-arrange flowsheet (see REARRANGE skill)
      ↓
10. Check model (check_model_completion_status)
      ↓
11. Run simulation (check_and_run)
```

> [!TIP]
> Step 9 explains how to fix messy process flow diagrams. For detailed instructions, call: `skills(category='core', name='REARRANGE')`


## Opening Existing Files Workflow

When working with an existing Aspen Plus file, follow this workflow to understand the model before making changes:

```
1. Open file (open_aspen_plus)
      ↓
2. Scan model information (list_aspen_info, info_type='all')
      ↓
3. Get components list (get_components_list)
      ↓
4. Get streams list (get_streams_list)
      ↓
5. Get blocks list (get_blocks_list)
      ↓
6. Check connections (get_block_connections for each block)
      ↓
7. Review stream conditions (get_stream_input_conditions_list)
      ↓
8. Review block specifications (get_block_input_specifications)
      ↓
9. Check model status (check_model_completion_status)
```



## Tool Categories

| Category | Key Tools |
|----------|-----------|
| streams | add_stream, connect_block_stream, set/get input/output |
| blocks | add_block, connect_block_stream, set/get input/output |
| properties | add_thermo_method, get_components_list |
| simulation | check_model, run_simulation, check_and_run |
| utils | unit_list, skills |
