---
name: components
description: Component configuration guides for defining chemical species in Aspen Plus.
---

# Component Configuration Skills

Guides for setting up chemical components in Aspen Plus models.

## Available Resources

| Resource | Description |
|----------|-------------|
| `COMPONENTS.md` | Component definition and CAS numbers |

## Usage

```python
skills(category='components', name='COMPONENTS')
```

## Workflow

1. `create_inp_file` - Create input file with components
2. `open_aspen_plus` - Open the file
3. `get_components_list` - Verify components
