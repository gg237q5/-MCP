---
description: Git workflow for safe development and deployment
---

# Git Workflow for AspenPlusMCP

## Branch Strategy

- `main` - 穩定版本，只接受經過測試的程式碼
- `develop` - 開發分支，日常開發在此進行
- `feature/*` - 新功能分支
- `fix/*` - 修復分支

## Daily Development Workflow

// turbo-all

### 1. Start new feature or fix
```powershell
git checkout develop
git pull origin develop
git checkout -b feature/your-feature-name
```

### 2. Make changes and commit
```powershell
git add .
git commit -m "feat: description of changes"
```

### 3. Push to GitHub
```powershell
git push origin feature/your-feature-name
```

### 4. Merge to develop (after testing)
```powershell
git checkout develop
git merge feature/your-feature-name
git push origin develop
```

### 5. When ready for release, merge to main
```powershell
git checkout main
git merge develop
git push origin main
```

## Commit Message Convention

| Prefix | Usage |
|--------|-------|
| `feat:` | New features |
| `fix:` | Bug fixes |
| `docs:` | Documentation changes |
| `refactor:` | Code refactoring |
| `chore:` | Maintenance tasks |
| `test:` | Adding or updating tests |

## Recovery Commands

### View commit history
```powershell
git log --oneline -20
```

### Undo last commit (keep changes)
```powershell
git reset --soft HEAD~1
```

### Undo last commit (discard changes)
```powershell
git reset --hard HEAD~1
```

### Revert a specific commit
```powershell
git revert <commit-hash>
```

### Reset to remote state
```powershell
git fetch origin
git reset --hard origin/main
```

### Stash changes temporarily
```powershell
git stash
# do something else
git stash pop
```

## Protecting Main Branch

To prevent accidental pushes to main, you can set up branch protection on GitHub:
1. Go to Repository Settings → Branches
2. Add branch protection rule for `main`
3. Enable "Require pull request before merging"
