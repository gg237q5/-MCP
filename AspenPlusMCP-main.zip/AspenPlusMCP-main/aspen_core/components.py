# -*- coding: utf-8 -*-
"""
Component operations for Aspen Plus COM interface.
Handles component listing.

Corresponds to: mcp_tools/components/
"""


class ComponentsMixin:
    """Mixin class for Aspen Plus component operations."""

    def ComponentsList(self) -> list:
        """Get the components-list in AspenFile with 'List Type'.

        :return: List. a list with all components name in AspenFile.
        """
        a_list = []
        for e in self.aspen.Tree.Elements("Data").Elements("Components").Elements("Comp-Lists").Elements(
                "GLOBAL").Elements("Input").Elements("CID").Elements:
            a_list.append(e.Value)
        return a_list
