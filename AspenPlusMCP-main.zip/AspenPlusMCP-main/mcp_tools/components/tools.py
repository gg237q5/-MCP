from mcp.types import Tool

get_components_list = Tool(
    name="get_components_list",
    description="This is a tool from the aspen-plus MCP server.\nCategory: Components\nRetrieve the list of all components in the Aspen Plus file",
    inputSchema={
        "type": "object",
        "properties": {},
        "required": []
    }
)

tools = [
    get_components_list
]
