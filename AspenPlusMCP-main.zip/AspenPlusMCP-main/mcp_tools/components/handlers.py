from typing import Dict, Any, List
from mcp.types import TextContent
from ..base import BaseHandler

class ComponentHandlers(BaseHandler):
    async def _get_components_list(self, args: Dict[str, Any]) -> List[TextContent]:
        """List all components in the simulation"""
        if not self.aspen_instance:
            return [TextContent(
                type="text",
                text="Aspen Plus is not running. Please use open_aspen_plus to open a file first."
            )]

        try:
            components = self.aspen_instance.ComponentsList()
            result = f"Components list ({len(components)} components):\n"
            for comp in components:
                result += f"- {comp}\n"

            return [TextContent(
                type="text",
                text=result
            )]
        except Exception as e:
            return [TextContent(
                type="text",
                text=f"Failed to retrieve components list: {str(e)}"
            )]
